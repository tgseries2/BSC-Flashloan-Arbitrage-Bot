const flashswapv2 = require('./flashswapv2.json');

module.exports = {
    flashswapv2,
};
